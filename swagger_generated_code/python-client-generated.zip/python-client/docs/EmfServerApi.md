# swagger_client.EmfServerApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**application_change_app_state**](EmfServerApi.md#application_change_app_state) | **PATCH** /app/{appID} | Changes an application state
[**application_delete_app**](EmfServerApi.md#application_delete_app) | **DELETE** /app/{appID} | Removes an application from the platform
[**application_deploy_app**](EmfServerApi.md#application_deploy_app) | **POST** /app | Deploys an application in the platform
[**application_get_all_apps**](EmfServerApi.md#application_get_all_apps) | **GET** /app | Gets information about all applications
[**application_get_app**](EmfServerApi.md#application_get_app) | **GET** /app/{appID} | Gets information about a specific application
[**application_get_app_tracing**](EmfServerApi.md#application_get_app_tracing) | **GET** /app/tracing/{appID} | Gets information about tracing of a specific application
[**application_hello_world**](EmfServerApi.md#application_hello_world) | **GET** / | EMF Working!


# **application_change_app_state**
> AppInfo application_change_app_state(app_id, state)

Changes an application state

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EmfServerApi()
app_id = 789 # int | ID of the application to change its state
state = swagger_client.AppState() # AppState | Application state (true to start, false to stop)

try:
    # Changes an application state
    api_response = api_instance.application_change_app_state(app_id, state)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EmfServerApi->application_change_app_state: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **int**| ID of the application to change its state | 
 **state** | [**AppState**](AppState.md)| Application state (true to start, false to stop) | 

### Return type

[**AppInfo**](AppInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **application_delete_app**
> AppInfo application_delete_app(app_id)

Removes an application from the platform

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EmfServerApi()
app_id = 789 # int | ID of the application to remove

try:
    # Removes an application from the platform
    api_response = api_instance.application_delete_app(app_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EmfServerApi->application_delete_app: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **int**| ID of the application to remove | 

### Return type

[**AppInfo**](AppInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **application_deploy_app**
> AppTotalInfo application_deploy_app(deploy)

Deploys an application in the platform

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EmfServerApi()
deploy = swagger_client.AppDeploy() # AppDeploy | Application object to be deployed

try:
    # Deploys an application in the platform
    api_response = api_instance.application_deploy_app(deploy)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EmfServerApi->application_deploy_app: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deploy** | [**AppDeploy**](AppDeploy.md)| Application object to be deployed | 

### Return type

[**AppTotalInfo**](AppTotalInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **application_get_all_apps**
> ArrayOfApps application_get_all_apps()

Gets information about all applications

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EmfServerApi()

try:
    # Gets information about all applications
    api_response = api_instance.application_get_all_apps()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EmfServerApi->application_get_all_apps: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ArrayOfApps**](ArrayOfApps.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **application_get_app**
> AppTotalInfo application_get_app(app_id)

Gets information about a specific application

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EmfServerApi()
app_id = 789 # int | ID of the application to get information

try:
    # Gets information about a specific application
    api_response = api_instance.application_get_app(app_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EmfServerApi->application_get_app: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **int**| ID of the application to get information | 

### Return type

[**AppTotalInfo**](AppTotalInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **application_get_app_tracing**
> str application_get_app_tracing(app_id)

Gets information about tracing of a specific application

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EmfServerApi()
app_id = 789 # int | ID of the application

try:
    # Gets information about tracing of a specific application
    api_response = api_instance.application_get_app_tracing(app_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EmfServerApi->application_get_app_tracing: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **app_id** | **int**| ID of the application | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **application_hello_world**
> application_hello_world()

EMF Working!

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EmfServerApi()

try:
    # EMF Working!
    api_instance.application_hello_world()
except ApiException as e:
    print("Exception when calling EmfServerApi->application_hello_world: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

